package com.jakegrze.sampleApp;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.jakegrze.sampleApp.R;

public class SampleAppActivity extends Activity {
    private static int ADD_REQUEST = 1;
	
	private ArrayList<Person> people;
    private SampleAppDatabase db;
    private int currentIndex;
    private TextView firstname;
    private TextView lastname;
    private TextView email;
    private TextView phone;
    private Button btnPrevious;
    private Button btnNext;
	
	/**
	 * @return the db
	 */
	public SampleAppDatabase getDb() {
		return db;
	}

	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        //Set up UI components.
        this.firstname = (TextView) this.findViewById(R.id.firstname);
    	this.lastname = (TextView) this.findViewById(R.id.lastname);
    	this.email = (TextView) this.findViewById(R.id.email);
    	this.phone = (TextView) this.findViewById(R.id.phone);
    	this.btnNext = (Button) this.findViewById(R.id.btnNext);
    	this.btnPrevious = (Button) this.findViewById(R.id.btnPrevious);
    	//Get persisted data from SQLite.
        this.db = new SampleAppDatabase(getApplicationContext(), "SampleApp.db");
        boolean startResult = db.StartDatabase();
        if (startResult){
        	boolean dataResult = db.GetAllPeople();
        	if (dataResult){
        		this.people = this.db.getPeople();
            	this.currentIndex = 0;
            	this.RefreshScreen();
        	}
        	else{
        		DisplayError("The database could not be read..");
            	this.finish();
        	}
        }
        else{
        	DisplayError("The database could not be started.");
        	this.finish();
        }
    }
    
    public void DisplayError(String message){
    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	builder.setMessage(message);
    	builder.setTitle("Error");
    	builder.setCancelable(false);
    	builder.setPositiveButton("OK", new OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}
		});
    	AlertDialog alert = builder.create();
    	alert.show();
    }
    
    public void MoveToNextRecord(View v){
    	this.currentIndex = this.currentIndex + 1;
    	this.RefreshScreen();
    }
    
    public void MoveToPreviousRecord(View v){
    	this.currentIndex = this.currentIndex - 1;
    	this.RefreshScreen();
    }
    
    private void RefreshScreen(){
    	Person person = new Person();
    	try{
    		person = this.people.get(this.currentIndex);
    		this.firstname.setText(person.getFirstName());
        	this.lastname.setText(person.getLastName());
        	this.email.setText(person.getEmail());
        	this.phone.setText(person.getPhone());
        	
        	if (this.currentIndex == this.people.size() - 1){
        		this.btnNext.setEnabled(false);
        	}
        	else {
        		this.btnNext.setEnabled(true);
        	}
        	
        	if (this.currentIndex == 0){
        		this.btnPrevious.setEnabled(false);
        	}
        	else{
        		this.btnPrevious.setEnabled(true);
        	}
    	}
    	catch(Exception e){
    		this.DisplayError("Can not display selected record.");
    	}
    }
    
    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
	    MenuInflater inflater = getMenuInflater();
	    inflater.inflate(R.menu.options, menu);
	    return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
	    // Handle item selection
		switch (item.getItemId()) {
        case R.id.add:
        	Intent intent = new Intent(SampleAppActivity.this, AddActivity.class);
			startActivityForResult(intent, ADD_REQUEST);
        default:
            return super.onOptionsItemSelected(item);
		}
	}
	
	/*
	 * (non-Javadoc)
	 * @see android.app.Activity#onActivityResult(int, int, android.content.Intent)
	 */
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent intent){
		if (requestCode == ADD_REQUEST && resultCode == RESULT_OK){
			//Get all of the people currently in the database.
			this.db.GetAllPeople();
			this.people = this.db.getPeople();
			//Set index to the most recently added person.
			this.currentIndex = this.people.size() - 1;
			this.RefreshScreen();
		}
	}	
	
	
}
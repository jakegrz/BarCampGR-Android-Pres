/**
 * 
 */
package com.jakegrze.sampleApp;

/**
 * @author jagrzego
 *
 */
public class Validator {
	
	public Validator(){
		super();
	}
	
	public boolean ValidateName(String name){
		boolean result = false;
		if (name.matches("^[A-Za-z]+")){
			result = true;
		}
		else{
			result = false;
		}
		return result;
	}
	
	public boolean ValidatePhone(String phone){
		boolean result;
		if (phone.matches("\\d\\d\\d([,\\s])?\\d\\d\\d([,\\s])?\\d\\d\\d\\d")){
			result = true;
		}
		else{
			result = false;
		}
		return result;
	}
	
	public boolean ValidateEmail(String email){
		boolean result;
		if (email.matches("^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")){
			result = true;
		}
		else{
			result = false;
		}
		return result; 
	}
}

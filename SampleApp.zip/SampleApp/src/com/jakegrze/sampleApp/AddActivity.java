/**
 * 
 */
package com.jakegrze.sampleApp;

import com.jakegrze.sampleApp.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * @author jagrzego
 * 
 */
public class AddActivity extends Activity {

	private EditText editFirst;
	private EditText editLast;
	private EditText editEmail;
	private EditText editPhone;
	private Button btnSave;
	private SampleAppDatabase db;
	private Intent mainIntent;
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add);
        this.mainIntent = getIntent();
        this.db = new SampleAppDatabase(getApplicationContext(), "SampleApp.db");
        boolean startResult = this.db.StartDatabase();
        editFirst = (EditText) this.findViewById(R.id.editFirst);
        editLast = (EditText) this.findViewById(R.id.editLast);
        editEmail = (EditText) this.findViewById(R.id.editEmail);
        editPhone = (EditText) this.findViewById(R.id.editPhone);
        btnSave = (Button) this.findViewById(R.id.btnSave);
        if (startResult == false){
        	this.DisplayError("Database could not be started.");
        }
    }
	
	public void SaveRecord(View v){
		boolean result;
		if (ValidateInput()){
			Person person = new Person(editFirst.getText().toString(), 
								   editLast.getText().toString(), 
								   editEmail.getText().toString(), 
								   editPhone.getText().toString());
			result = this.db.AddPerson(person);
			if (result == false){
				DisplayError("The record could not be saved.");
			}
			else{
				setResult(RESULT_OK, this.mainIntent);
				this.finish();
			}
		}
	}
	
	public void DisplayError(String message){
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	builder.setMessage(message);
    	builder.setTitle("Error");
    	builder.setCancelable(false);
    	builder.setPositiveButton("OK", new OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}
		});
    	AlertDialog alert = builder.create();
    	alert.show();
    }
	
	private boolean ValidateInput(){
		boolean result = true;
		
		Validator validate = new Validator();
		if (validate.ValidateName(editFirst.getText().toString()) == false){
			editFirst.setError("Must have a valid First Name.");
			result = false;
		}
		if (validate.ValidateName(editLast.getText().toString()) == false){
			editLast.setError("Must have a valid Last Name.");
			result = false;
		}
		if (validate.ValidateEmail(editEmail.getText().toString()) == false){
			editEmail.setError("Must have a valid email address. Ex. example@example.com");
			result = false;
		}
		if (validate.ValidatePhone(editPhone.getText().toString()) == false){
			editPhone.setError("Must have a valid phone number. Ex. 555 555 5555");
			result = false;
		}
		return result;
	}
}

package com.jakegrze.sampleApp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.jakegrze.sampleApp.Person;

public class SampleAppDatabase {
   //SQL Constants
   static final String CREATE_PEOPLE_TABLE = "CREATE TABLE tbl_people (" +
		   									 "id INTEGER PRIMARY KEY AUTOINCREMENT," +
		   									 "firstname TEXT," +
		   									 "lastname TEXT," +
		   									 "email TEXT," +
		   									 "phone TEXT);";
   static final String CHECK_TABLES_EXISTS = "SELECT DISTINCT tbl_name from sqlite_master where tbl_name = 'tbl_people'";
   static final String SELECT_ALL_PEOPLE = "SELECT " +
		   								   "id, " +
		   								   "firstname, " +
		   								   "lastname, " +
		   								   "email, " +
		   								   "phone " +
		   								   "FROM tbl_people " +
		   								   "ORDER BY lastname;";
   
	
   //Class Fields	
   SQLiteDatabase db;
   Context context;
   String dbName;
   String status;
   ArrayList<Person> people;

/**
 * Constructor for SampleAppDatabase class.
 * @param context
 * @param dbName
 * @author jagrzego
 */
public SampleAppDatabase(Context context, String dbName) {
	super();
	this.people = new ArrayList<Person>();
	this.context = context;
	this.dbName = dbName;
}

/**
 * @return the status
 */
public String getStatus() {
	return status;
}

/**
 * @return the people
 */
public ArrayList<Person> getPeople() {
	return people;
}

/**
 * Creates or opens the database for the application.
 * @author jagrzego
 * @return result
 */
public boolean StartDatabase(){
	boolean result = false;
	try{
		this.db = this.context.openOrCreateDatabase(this.dbName, SQLiteDatabase.CREATE_IF_NECESSARY, null);
		this.db.setLocale(Locale.getDefault());
		this.db.setLockingEnabled(true);
		this.db.setVersion(1);
		if (!TablesExists()){
			result = CreateTables();
		}
		else{
			result = true;
		}
	}
	catch(Exception e){
		this.status = e.getMessage();
		result = false;
	}
	
	return result;
}

private boolean TablesExists(){
	boolean result = false;
	try{
		Cursor cursor = db.rawQuery(CHECK_TABLES_EXISTS, null);
		if(cursor!=null) {
	        if(cursor.getCount()>0) {
	            cursor.close();
	            result = true;
	        }
	        else{
	        	cursor.close();
	        }
	    }
		else result = false;
		
	}
	catch (Exception e){
		result = false;
	}
	return result;
}

private boolean CreateTables(){
	boolean result = false;
	try{
		this.db.execSQL(CREATE_PEOPLE_TABLE);
		result = true;
	}
	catch (Exception e){
		this.status = e.getMessage();
		result = false;
	}
	return result;
}

public boolean GetAllPeople(){
	boolean result = false;
	try{
		Cursor c = this.db.rawQuery(SELECT_ALL_PEOPLE, null);
		this.people = ProcessQuery(c);
		c.close();
		result = true;
	}
	catch (Exception e){
		this.status = e.getMessage();
		result = false;
	}
	return result;
}

private ArrayList<Person> ProcessQuery(Cursor c){
	ArrayList<Person> peopleList = new ArrayList<Person>();
	c.moveToFirst();
	while (c.isAfterLast() == false){
		Person person = new Person();
		person.setId((Integer) c.getInt(0));
		person.setFirstName(c.getString(1));
		person.setLastName(c.getString(2));
		person.setEmail(c.getString(3));
		person.setPhone(c.getString(4));
		peopleList.add(person);
		c.moveToNext();
	}
	Collections.sort(peopleList, new Comparator<Person>() {
		public int compare(Person person1, Person person2){
			return person1.getId().compareTo(person2.getId());
		}
	});
	peopleList.trimToSize();
	return peopleList;
}

/**
 * @author jagrzego
 * @param person
 * @return result
 * Adds a new record to the database.
 */
public boolean AddPerson(Person person){
	boolean result = false;
	try{
		ContentValues values = new ContentValues();
		//Set values to insert.
		values.put("firstname", person.getFirstName());
		values.put("lastname", person.getLastName());
		values.put("email", person.getEmail());
		values.put("phone", person.getPhone());
		//insert the new record. Function returns the id of the new record.
		long newRecord = db.insert("tbl_people", null, values);
		if (newRecord >= 0){
			result = true;
			this.GetAllPeople();
		}
		else{
			result = false;
		}
	}
	catch(Exception e){
		this.status = e.getMessage();
		result = false;
	}
	return result;
}

}
